package org.example.assignment2;

import java.util.List;

public class Product {
    public int id;
    public String brand;
    public String name;
    public String price;
    public String price_sign;
    public String currency;
    public String image_link;
    public String product_link;
    public String website_link;
    public String description;
    public String rating;
    public String category;
    public String product_type;
    public List<String> tag_list;
    public String created_at;
    public String updated_at;
    public String product_api_url;
    public String api_featured_image;
    public List<Color> product_colors;

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPriceSign() {
        return price_sign;
    }

    public void setPriceSign(String price_sign) {
        this.price_sign = price_sign;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getImageLink() {
        return image_link;
    }

    public void setImageLink(String image_link) {
        this.image_link = image_link;
    }

    public String getProductLink() {
        return product_link;
    }

    public void setProductLink(String product_link) {
        this.product_link = product_link;
    }

    public String getWebsiteLink() {
        return website_link;
    }

    public void setWebsiteLink(String website_link) {
        this.website_link = website_link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProductType() {
        return product_type;
    }

    public void setProductType(String product_type) {
        this.product_type = product_type;
    }

    public List<String> getTagList() {
        return tag_list;
    }

    public void setTagList(List<String> tag_list) {
        this.tag_list = tag_list;
    }

    public String getCreatedAt() {
        return created_at;
    }

    public void setCreatedAt(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdatedAt() {
        return updated_at;
    }

    public void setUpdatedAt(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getProductApiUrl() {
        return product_api_url;
    }

    public void setProductApiUrl(String product_api_url) {
        this.product_api_url = product_api_url;
    }

    public String getApiFeaturedImage() {
        return api_featured_image;
    }

    public void setApiFeaturedImage(String api_featured_image) {
        this.api_featured_image = api_featured_image;
    }

    public List<Color> getProductColors() {
        return product_colors;
    }

    public void setProductColors(List<Color> product_colors) {
        this.product_colors = product_colors;
    }

    // Inner Color class
    public static class Color {
        public String hex_value;
        public String colour_name;

        // Getters and setters

        public String getHexValue() {
            return hex_value;
        }

        public void setHexValue(String hex_value) {
            this.hex_value = hex_value;
        }

        public String getColourName() {
            return colour_name;
        }

        public void setColourName(String colour_name) {
            this.colour_name = colour_name;
        }
    }
}



