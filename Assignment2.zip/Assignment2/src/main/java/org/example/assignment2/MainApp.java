package org.example.assignment2;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;

public class MainApp extends Application {

    private List<Product> products; // List of products obtained from the API
    private ComboBox<String> brandComboBox; // ComboBox to select a brand
    private VBox productDisplay; // VBox to display products

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Retrieve JSON data from the API
        String jsonData = ApiClient.getData();
        // Parse JSON data to get the list of products
        products = JsonParser.parseProducts(jsonData);

        // Extract unique brands, ignoring null values and sorting them
        List<String> brands = products.stream()
                .map(Product::getBrand)
                .filter(brand -> brand != null) // Filter out null values
                .distinct()
                .sorted()
                .collect(Collectors.toList());

        // Convert the list of brands to an ObservableList
        ObservableList<String> brandList = FXCollections.observableArrayList(brands);
        brandComboBox = new ComboBox<>(brandList); // Create ComboBox with brand list
        brandComboBox.setPromptText("Select a Brand"); // Set prompt text
        brandComboBox.setOnAction(e -> updateProductDisplay(brandComboBox.getValue())); // Set action on selection change

        // Initialize product display VBox
        productDisplay = new VBox();
        productDisplay.setPadding(new Insets(10));
        productDisplay.setSpacing(10);

        // Root VBox layout
        VBox root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);

        // Top bar HBox layout
        HBox topBar = new HBox();
        topBar.setPadding(new Insets(10));
        topBar.setStyle("-fx-background-color: #FFC0CB;"); // Light pink background
        topBar.getChildren().add(new Label("Make Up Visualizer")); // Add label to top bar

        // Add top bar, brand ComboBox, and product display to root
        root.getChildren().addAll(topBar, brandComboBox, productDisplay);

        // Create scene with root layout
        Scene scene = new Scene(root, 800, 600);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // Add CSS stylesheet
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("makeUp.png"))); // Set application icon

        primaryStage.setScene(scene); // Set scene to primary stage
        primaryStage.setTitle("Makeup Products"); // Set window title
        primaryStage.show(); // Display window
    }

    // Update product display based on selected brand
    private void updateProductDisplay(String selectedBrand) {
        productDisplay.getChildren().clear(); // Clear current display

        // Filter products by selected brand
        List<Product> filteredProducts = products.stream()
                .filter(p -> selectedBrand.equals(p.getBrand()))
                .collect(Collectors.toList());

        // GridPane layout for displaying products
        GridPane gridPane = new GridPane();
        int row = 0;
        int col = 0;
        for (Product product : filteredProducts) {
            if (product.getImageLink() == null || product.getPrice() == null) {
                continue; // Skip products without image or price
            }

            // Create ImageView for product image
            ImageView imageView = new ImageView(new Image(product.getImageLink()));
            imageView.setFitWidth(150); // Set image width
            imageView.setPreserveRatio(true); // Preserve aspect ratio

            // Create Text for product price
            Text price = new Text(product.getPrice());

            // VBox layout for individual product
            VBox productBox = new VBox(imageView, price);
            productBox.setAlignment(Pos.CENTER); // Center align
            productBox.setPadding(new Insets(5));
            productBox.setStyle("-fx-border-color: #FF69B4; -fx-border-width: 2px;"); // Pink border

            // Add product box to grid pane
            gridPane.add(productBox, col, row);

            col++;
            if (col > 4) { // Number of columns
                col = 0;
                row++;
            }
        }

        productDisplay.getChildren().add(gridPane); // Add grid pane to product display
    }

    public static void main(String[] args) {
        launch(args); // Launch JavaFX application
    }
}
